void initUART();
void eputc(char c);
char egetc();
void printString(char *String);
void printHex(unsigned int Number);
